use std::time::{SystemTime, UNIX_EPOCH};

// ============================================================
// CURRENT TIME
// ============================================================
pub fn now_millis() -> u128 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis())
        .unwrap_or(0)
}
